compile:
' gcc main.c '